https://www.stgraber.org/2012/03/04/booting-an-ubuntu-12-04-virtual-machine-in-an-lxc-container/
http://askubuntu.com/questions/249180/how-do-i-migrate-a-virtualbox-image-to-an-lxc-container
http://www.efecte.com/blog/how-we-converted-3-apps-to-cloud-with-docker
http://kracekumar.com/post/70198562577/autogenerate-dockerfile-from-ubuntu-image



Running multiple processes in one container:
[Base-image docker](https://github.com/phusion/baseimage-docker/#docker_single_process)
[ycombinator discussion](https://news.ycombinator.com/item?id=7951102)

[supervisord]
(http://coinbase.com/charts)


[Guardrail / Scriptrock convert docker image to dockerfile]
(http://www.scriptrock.com/blog/comparing-containers-generating-dockerfiles-guardrail)




[Reference for backup/restore of packages on all major distributions]
(http://www.nixtutor.com/linux/keep-a-backup-of-installed-packages/)



Alternatives to Docker:

[Flockport]
(http://flockport.com)

Some vague reference to converting images into containers:
[StackEngine]
(http://stackengine.com)