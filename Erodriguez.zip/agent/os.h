void get_installed_cmd(char **cmd);
void get_dependencies_fmt(char **fmt);