vm2docker
==========

A library to automate the conversion of linux-based vms to a set of docker containers
